package example.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ContactDependancyInjection {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config2.xml");
		Object obj = context.getBean("myContact");
		System.out.println(obj);

	}

}
