package example.spring.core;

public interface GreetingService {
     String sayGreeting();
}
