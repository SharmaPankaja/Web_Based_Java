package example.spring.core;

public class BeanImpl {

	public BeanImpl() {
		System.out.println("Inside BeanImpl()");
	}

}
