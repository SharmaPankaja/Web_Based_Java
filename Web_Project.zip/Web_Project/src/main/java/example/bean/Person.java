package example.bean;

public class Person {
 private String name;
 private int age;
 private float weight;
 
	public Person() {
 System.out.println("Inside Person()");
	}

	public String getName() {
		System.out.println("Getting the name");
		return name;
	}

	public void setName(String name) {
		System.out.println("Setting the name");
		this.name = name;
	}

	public int getAge() {
		System.out.println("Get Age");
		return age;
	}

	public void setAge(int age) {
		System.out.println("Set Age");
		this.age = age;
	}

	public float getWeight() {
		System.out.println("Get Weight");
		return weight;
	}

	public void setWeight(float weight) {
		System.out.println("Set Weight");
		this.weight = weight;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", weight=" + weight + "]";
	}

}
