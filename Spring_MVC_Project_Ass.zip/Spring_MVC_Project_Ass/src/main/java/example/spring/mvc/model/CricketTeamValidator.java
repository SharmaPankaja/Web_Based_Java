package example.spring.mvc.model;

public class CricketTeamValidator {
	public static boolean isValid(CricketTeam teamObject) {
		boolean result = false;
		String currentteamId = teamObject.getTeamId();
		String currentteamName = teamObject.getTeamName();
		if(currentteamId.equals("admin") && currentteamName.equals("sharma123"))
			result = true;
		return result;
}
}