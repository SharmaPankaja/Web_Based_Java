package example.spring.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import example.spring.mvc.model.CricketTeam;
import example.spring.mvc.model.CricketTeamValidator;


@Controller //marks this class as a Controller of Spring MVC Application
@SessionAttributes({"loggedInUser"})
public class SpringMvcController {
	//@RequestMapping("/doGreet")//Providing mapping between the URL and
	@GetMapping("/home")
	public String getIndexPage() {
		System.out.println("Inside getIndexPage()");
		return "index";//Returning a view name
	}
	
	//@RequestMapping("/doLogin")
	@GetMapping("/doLogin")
	public String getLoginPage() {
		System.out.println("Inside getLoginPage()");
		return "login";
	}
	
	//@RequestMapping(value="/doValidateAgain",method=RequestMethod.POST)
	@PostMapping("/doValidateAgain")
	public String getResultPageAgain(
			@RequestParam("tid") String teamId,
			@RequestParam("teamname") String teamName,
			@RequestParam("trank") int tRank,
			@RequestParam("odirank") int odiRank,
			@RequestParam("t20rank") int t20Rank,
			Model modelObject 
			) {
		String resultPage = "failurePage";
		CricketTeam cricketTeamDataModel = new CricketTeam(teamId, teamName, tRank, odiRank, t20Rank);
		//Passing the Model object to UserValidation for validation.
		boolean valid = CricketTeamValidator.isValid(cricketTeamDataModel);
		if(valid) {
			resultPage = "successPage";
			//Adding a userName in the Model object
			modelObject.addAttribute("loggedInUser", teamId);
		}
		return resultPage;
	}
}
